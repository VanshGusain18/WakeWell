//
//  HapticPickerViewController.swift
//  WakeWell
//
//  Backed by HapticPickerViewController.xib.
//  Simple static table for haptic pattern selection.
//

import UIKit

protocol HapticPickerDelegate: AnyObject {
    func didSelectHaptic(_ name: String)
}

final class HapticPickerViewController: UITableViewController {

    // MARK: - Public config
    var selectedHapticLabel: String = SoundSelection.default.haptic
    weak var delegate: HapticPickerDelegate?

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        applyTheme()
        configureBackButton()
    }

    // MARK: - Setup

    private func applyTheme() {
        view.backgroundColor      = WakeWellTheme.background
        tableView.backgroundColor = WakeWellTheme.background
        navigationController?.navigationBar.tintColor = WakeWellTheme.accentPurple
        navigationItem.largeTitleDisplayMode = .never
    }

    private func configureBackButton() {
        navigationItem.leftBarButtonItem = UIBarButtonItem(
            image: UIImage(systemName: "chevron.left"),
            style: .plain, target: self, action: #selector(backTapped)
        )
        navigationItem.leftBarButtonItem?.tintColor = WakeWellTheme.accentPurple
    }

    @objc private func backTapped() {
        if navigationController?.viewControllers.first === self {
            dismiss(animated: true)
        } else {
            navigationController?.popViewController(animated: true)
        }
    }

    // MARK: - UITableViewDataSource / Delegate

    override func tableView(_ tableView: UITableView,
                            cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = super.tableView(tableView, cellForRowAt: indexPath)
        cell.backgroundColor             = WakeWellTheme.cardBackground
        cell.contentView.backgroundColor = WakeWellTheme.cardBackground
        cell.textLabel?.textColor        = WakeWellTheme.labelPrimary
        cell.tintColor                   = WakeWellTheme.accentPurple
        cell.selectionStyle              = .none

        let cellTitle     = cell.textLabel?.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let selectedTitle = selectedHapticLabel.trimmingCharacters(in: .whitespacesAndNewlines)
        cell.accessoryType = cellTitle == selectedTitle ? .checkmark : .none
        return cell
    }

    override func tableView(_ tableView: UITableView,
                            willDisplayHeaderView view: UIView,
                            forSection section: Int) {
        guard let header = view as? UITableViewHeaderFooterView else { return }
        header.tintColor = WakeWellTheme.background
        header.textLabel?.textColor = WakeWellTheme.labelSecondary
    }

    override func tableView(_ tableView: UITableView,
                            didSelectRowAt indexPath: IndexPath) {
        UISelectionFeedbackGenerator().selectionChanged()
        guard let name = tableView.cellForRow(at: indexPath)?.textLabel?.text?
            .trimmingCharacters(in: .whitespacesAndNewlines),
              !name.isEmpty else { return }
        selectedHapticLabel = name
        delegate?.didSelectHaptic(name)
        tableView.reloadData()

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.20) { [weak self] in
            self?.backTapped()
        }
    }
}
