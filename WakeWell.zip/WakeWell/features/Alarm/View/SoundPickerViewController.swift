//
//  SoundPickerViewController.swift
//  WakeWell
//
//  Backed by SoundPickerViewController.xib.
//  Presents the list of alarm sounds and routes to the haptic picker.
//

import UIKit
import AVFoundation

protocol SoundPickerDelegate: AnyObject {
    func didSelectSound(_ name: String, haptic: String)
}

final class SoundPickerViewController: UITableViewController {

    // MARK: - XIB Outlets
    @IBOutlet private weak var hapticSummaryLabel: UILabel!

    // MARK: - Public config (set before push)
    var selectedSoundName: String = SoundSelection.default.sound
    var selectedHaptic:    String = SoundSelection.default.haptic
    weak var delegate: SoundPickerDelegate?

    // MARK: - Data source
    private let sounds: [String] = [
        "Early Riser (Default)",
        "First Light",
        "Helios",
        "Orbit",
        "Pillar",
        "Spring Time",
        "Under the Stars",
        "Wellspring"
    ]

    private var selectedIndexPath: IndexPath? {
        guard let idx = sounds.firstIndex(of: selectedSoundName) else { return nil }
        return IndexPath(row: idx, section: 1)
    }

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        applyTheme()
        configureBackButton()
        hapticSummaryLabel?.text = selectedHaptic
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        layoutHapticLabel()
    }

    // MARK: - Setup

    private func applyTheme() {
        view.backgroundColor      = WakeWellTheme.background
        tableView.backgroundColor = WakeWellTheme.background
        navigationController?.navigationBar.tintColor = WakeWellTheme.accentPurple
        navigationItem.largeTitleDisplayMode = .never
        hapticSummaryLabel?.textColor     = WakeWellTheme.labelSecondary
        hapticSummaryLabel?.textAlignment = .right
        hapticSummaryLabel?.adjustsFontSizeToFitWidth = true
        hapticSummaryLabel?.minimumScaleFactor = 0.7
    }

    private func configureBackButton() {
        navigationItem.leftBarButtonItem = UIBarButtonItem(
            image: UIImage(systemName: "chevron.left"),
            style: .plain, target: self, action: #selector(backTapped)
        )
        navigationItem.leftBarButtonItem?.tintColor = WakeWellTheme.accentPurple
    }

    private func layoutHapticLabel() {
        guard let label = hapticSummaryLabel, let container = label.superview else { return }
        let w = min(170, max(120, container.bounds.width * 0.45))
        var frame = label.frame
        frame.size.width = w
        frame.origin.x   = container.bounds.width - 16 - w
        label.frame      = frame.integral
    }

    // MARK: - Actions

    @objc private func backTapped() {
        if navigationController?.viewControllers.first === self {
            dismiss(animated: true)
        } else {
            navigationController?.popViewController(animated: true)
        }
    }

    // MARK: - UITableViewDataSource / Delegate

    override func tableView(_ tableView: UITableView,
                            cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = super.tableView(tableView, cellForRowAt: indexPath)
        cell.backgroundColor             = WakeWellTheme.cardBackground
        cell.contentView.backgroundColor = WakeWellTheme.cardBackground
        cell.textLabel?.textColor        = WakeWellTheme.labelPrimary
        cell.tintColor                   = WakeWellTheme.accentPurple
        cell.selectionStyle              = .none
        if indexPath.section == 1 {
            cell.accessoryType = indexPath == selectedIndexPath ? .checkmark : .none
        } else {
            cell.accessoryType = .disclosureIndicator
        }
        return cell
    }

    override func tableView(_ tableView: UITableView,
                            willDisplayHeaderView view: UIView,
                            forSection section: Int) {
        guard let header = view as? UITableViewHeaderFooterView else { return }
        header.tintColor = WakeWellTheme.background
        header.textLabel?.textColor = WakeWellTheme.labelSecondary
    }

    override func tableView(_ tableView: UITableView,
                            didSelectRowAt indexPath: IndexPath) {
        guard indexPath.section == 1 else { return }
        UISelectionFeedbackGenerator().selectionChanged()

        guard let name = tableView.cellForRow(at: indexPath)?.textLabel?.text else { return }
        selectedSoundName = name
        delegate?.didSelectSound(name, haptic: selectedHaptic)
        tableView.reloadData()

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) { [weak self] in
            self?.backTapped()
        }
    }

    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let dest = segue.destination as? HapticPickerViewController {
            dest.delegate             = self
            dest.selectedHapticLabel  = selectedHaptic
        }
    }
}

// MARK: - HapticPickerDelegate
extension SoundPickerViewController: HapticPickerDelegate {
    func didSelectHaptic(_ name: String) {
        selectedHaptic              = name
        hapticSummaryLabel?.text    = name
        delegate?.didSelectSound(selectedSoundName, haptic: name)
    }
}
