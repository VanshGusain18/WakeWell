//
//  AlarmPickerCell.swift
//  WakeWell

import UIKit

final class AlarmPickerCell: UITableViewCell {

    static let reuseID = "AlarmPickerCell"

    @IBOutlet weak var timePicker:    CircularTimePicker!
    @IBOutlet weak var bedtimeLabel:  UILabel!
    @IBOutlet weak var durationLabel: UILabel!
    @IBOutlet weak var wakeupLabel:   UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle       = .none
        backgroundColor      = .clear
        contentView.backgroundColor = .clear
        timePicker.applyTheme()
    }

    func refreshLabels() {
        bedtimeLabel.text  = timePicker.formatTime(timePicker.bedtime)
        wakeupLabel.text   = timePicker.formatTime(timePicker.wakeUp)
        let diff = Calendar.current.dateComponents(
            [.hour, .minute], from: timePicker.bedtime, to: timePicker.wakeUp
        )
        var h = diff.hour ?? 0
        if h < 0 { h += 24 }
        durationLabel.text = "\(h) hr"
    }
}
