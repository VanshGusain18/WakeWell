//
//  AlarmOptionViewController.swift
//  WakeWell
//
//  UITableViewController backed by AlarmOptionViewController.xib.
//  All UI state flows through AlarmViewModel.
//

import UIKit
import UserNotifications

final class AlarmOptionViewController: UITableViewController {

    // MARK: - XIB Outlets

    // Section 0 — circular time picker
    @IBOutlet private weak var timePicker: CircularTimePicker!
    @IBOutlet private weak var bedtimeLabel: UILabel!
    @IBOutlet private weak var wakeupLabel: UILabel!
    @IBOutlet private weak var durationLabel: UILabel!

    // Section 1 — Wake Up
    @IBOutlet private weak var wakeUpToggle: UISwitch!
    @IBOutlet private weak var wakeUpSoundSummaryLabel: UILabel!
    @IBOutlet private weak var wakeUpVolumeSlider: UISlider!

    // Section 2 — Bedtime
    @IBOutlet private weak var bedTimeToggle: UISwitch!
    @IBOutlet private weak var bedTimeSoundSummaryLabel: UILabel!
    @IBOutlet private weak var bedTimeVolumeSlider: UISlider!

    // Section 1 — smart window button
    @IBOutlet private weak var smartWindowButton: UIButton!

    // Nav bar
    @IBOutlet private weak var doneBarButton: UIBarButtonItem!

    // MARK: - Internal state
    private let viewModel = AlarmViewModel()

    // Rows that should collapse when the parent toggle is off
    private let wakeUpOptionRows: Set<Int> = [1, 2, 3]
    private let bedtimeOptionRows: Set<Int> = [1, 2]

    // Which section is routing to the sound picker
    private var activeSection: Int = 1

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
        viewModel.requestNotificationPermission()

        applyTheme()
        configureTimePicker()
        configureSmartWindowMenu()
        configureSliders()
        refreshTimeLabels()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        applyTheme()
        refreshSoundLabels()
    }

    // MARK: - Setup helpers

    private func configureTimePicker() {
        timePicker.addTarget(self, action: #selector(timePickerChanged), for: .valueChanged)
        timePicker.applyTheme()
    }

    private func configureSmartWindowMenu() {
        let current = SmartWindow(rawValue: smartWindowButton.title(for: .normal) ?? "") ?? .thirty
        let actions = SmartWindow.allCases.map { window in
            UIAction(title: window.rawValue, state: window == current ? .on : .off) { [weak self] _ in
                self?.viewModel.config.smartWindowMinutes = window.minutes
                self?.smartWindowButton.setTitle(window.rawValue, for: .normal)
                self?.configureSmartWindowMenu()
            }
        }
        smartWindowButton.menu = UIMenu(title: "Smart Wake Window",
                                        options: .singleSelection,
                                        children: actions)
        smartWindowButton.showsMenuAsPrimaryAction = true
    }

    private func configureSliders() {
        styleSlider(wakeUpVolumeSlider)
        styleSlider(bedTimeVolumeSlider)
        wakeUpVolumeSlider.value  = viewModel.config.wakeUpVolume
        bedTimeVolumeSlider.value = viewModel.config.bedtimeVolume
    }

    private func refreshTimeLabels() {
        bedtimeLabel.text  = timePicker.formatTime(timePicker.bedtime)
        wakeupLabel.text   = timePicker.formatTime(timePicker.wakeUp)
        let diff = Calendar.current.dateComponents([.hour, .minute],
                                                   from: timePicker.bedtime,
                                                   to: timePicker.wakeUp)
        var hours = diff.hour ?? 0
        if hours < 0 { hours += 24 }
        durationLabel.text = "\(hours) hr"
    }

    private func refreshSoundLabels() {
        wakeUpSoundSummaryLabel.text  = viewModel.config.wakeUpSound.displayText
        bedTimeSoundSummaryLabel.text = viewModel.config.bedtimeSound.displayText
    }

    // MARK: - Theme

    private func applyTheme() {
        view.backgroundColor      = WakeWellTheme.background
        tableView.backgroundColor = WakeWellTheme.background

        navigationController?.navigationBar.tintColor = WakeWellTheme.accentPurple
        navigationController?.navigationBar.prefersLargeTitles = true
        navigationItem.largeTitleDisplayMode = .always

        doneBarButton.tintColor = WakeWellTheme.accentPurple

        [bedtimeLabel, wakeupLabel, durationLabel].forEach {
            $0?.textColor = WakeWellTheme.labelPrimary
        }

        [wakeUpSoundSummaryLabel, bedTimeSoundSummaryLabel].forEach {
            $0?.textColor     = WakeWellTheme.labelSecondary
            $0?.textAlignment = .right
            $0?.adjustsFontSizeToFitWidth = true
            $0?.minimumScaleFactor = 0.7
            $0?.lineBreakMode = .byTruncatingTail
        }

        wakeUpToggle.onTintColor  = WakeWellTheme.accentPurple
        bedTimeToggle.onTintColor = WakeWellTheme.accentPurple
        smartWindowButton.setTitleColor(WakeWellTheme.accentPurple, for: .normal)

        tableView.reloadData()
    }

    // MARK: - Actions

    @IBAction private func timePickerChanged(_ sender: CircularTimePicker) {
        viewModel.config.wakeUpTime = sender.wakeUp
        viewModel.config.bedtime    = sender.bedtime
        refreshTimeLabels()
    }

    @IBAction private func wakeUpToggleChanged(_ sender: UISwitch) {
        viewModel.config.wakeUpEnabled = sender.isOn
        animateSectionRows(section: 1, rows: wakeUpOptionRows, visible: sender.isOn)
    }

    @IBAction private func bedTimeToggleChanged(_ sender: UISwitch) {
        viewModel.config.bedtimeEnabled = sender.isOn
        animateSectionRows(section: 2, rows: bedtimeOptionRows, visible: sender.isOn)
    }

    @IBAction private func wakeUpVolumeChanged(_ sender: UISlider) {
        viewModel.config.wakeUpVolume = sender.value
    }

    @IBAction private func bedTimeVolumeChanged(_ sender: UISlider) {
        viewModel.config.bedtimeVolume = sender.value
    }

    @IBAction private func doneTapped(_ sender: UIBarButtonItem) {
        viewModel.saveAlarm()
    }

    // MARK: - Section collapse/expand

    private func animateSectionRows(section: Int, rows: Set<Int>, visible: Bool) {
        tableView.beginUpdates()
        let indexPaths = rows.map { IndexPath(row: $0, section: section) }
        tableView.reloadRows(at: indexPaths, with: visible ? .fade : .fade)
        tableView.endUpdates()
    }

    // MARK: - UITableViewDelegate

    override func tableView(_ tableView: UITableView,
                            heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 { return 454 }
        if indexPath.section == 1 && wakeUpOptionRows.contains(indexPath.row) {
            return wakeUpToggle.isOn ? UITableView.automaticDimension : 0
        }
        if indexPath.section == 2 && bedtimeOptionRows.contains(indexPath.row) {
            return bedTimeToggle.isOn ? UITableView.automaticDimension : 0
        }
        return UITableView.automaticDimension
    }

    override func tableView(_ tableView: UITableView,
                            willDisplay cell: UITableViewCell,
                            forRowAt indexPath: IndexPath) {
        let shouldHide: Bool
        if indexPath.section == 1 && wakeUpOptionRows.contains(indexPath.row) {
            shouldHide = !wakeUpToggle.isOn
        } else if indexPath.section == 2 && bedtimeOptionRows.contains(indexPath.row) {
            shouldHide = !bedTimeToggle.isOn
        } else {
            shouldHide = false
        }

        cell.isHidden       = shouldHide
        cell.clipsToBounds  = true
        cell.backgroundColor             = WakeWellTheme.cardBackground
        cell.contentView.backgroundColor = WakeWellTheme.cardBackground
        cell.textLabel?.textColor        = WakeWellTheme.labelPrimary
        cell.detailTextLabel?.textColor  = WakeWellTheme.labelSecondary
        cell.tintColor                   = WakeWellTheme.accentPurple
        cell.selectionStyle              = .none

        let bg = UIView()
        bg.backgroundColor = WakeWellTheme.cardBackground
        cell.selectedBackgroundView = bg

        styleSubviews(of: cell.contentView)
    }

    override func tableView(_ tableView: UITableView,
                            willDisplayHeaderView view: UIView,
                            forSection section: Int) {
        guard let header = view as? UITableViewHeaderFooterView else { return }
        header.tintColor = WakeWellTheme.background
        header.textLabel?.textColor = WakeWellTheme.labelSecondary
    }

    // MARK: - Navigation / Sound picker

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let dest = segue.destination as? SoundPickerViewController {
            dest.delegate = self
            if let ip = tableView.indexPathForSelectedRow {
                activeSection = ip.section
            }
            let sel = activeSection == 1
                ? viewModel.config.wakeUpSound
                : viewModel.config.bedtimeSound
            dest.selectedSoundName = sel.sound
            dest.selectedHaptic    = sel.haptic
        }
    }

    // MARK: - Private helpers

    /// Recursively applies theme colours to all subviews of a cell's contentView.
    private func styleSubviews(of view: UIView) {
        for sub in view.subviews {
            switch sub {
            case let lbl  as UILabel  where lbl !== wakeUpSoundSummaryLabel
                                        && lbl !== bedTimeSoundSummaryLabel:
                lbl.textColor = WakeWellTheme.labelPrimary
            case let btn  as UIButton:
                btn.setTitleColor(WakeWellTheme.accentPurple, for: .normal)
            case let iv   as UIImageView:
                iv.tintColor = WakeWellTheme.labelSecondary
            case let cp   as CircularTimePicker:
                cp.applyTheme()
            default:
                if sub.backgroundColor != .clear {
                    sub.backgroundColor = WakeWellTheme.cardBackground
                }
            }
            styleSubviews(of: sub)
        }
    }
}

// MARK: - AlarmViewModelDelegate
extension AlarmOptionViewController: AlarmViewModelDelegate {
    func alarmDidSave(wakeUpTime: Date, isSmart: Bool) {
        let formatter = DateFormatter()
        formatter.dateFormat = "h:mm a"
        let timeStr = formatter.string(from: wakeUpTime)
        let message = isSmart
            ? "Smart alarm set for \(timeStr) — we'll wake you at the lightest sleep phase."
            : "Your alarm has been set for \(timeStr)."
        DispatchQueue.main.async {
            self.showConfirmation(message: message)
        }
    }

    func alarmSaveFailed(message: String) {
        DispatchQueue.main.async {
            self.showConfirmation(message: message)
        }
    }

    private func showConfirmation(message: String) {
        let alert = UIAlertController(title: "Alarm Set",
                                      message: message,
                                      preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default) { [weak self] _ in
            self?.dismiss(animated: true)
        })
        present(alert, animated: true)
    }
}

// MARK: - SoundPickerDelegate
extension AlarmOptionViewController: SoundPickerDelegate {
    func didSelectSound(_ name: String, haptic: String) {
        let selection = SoundSelection(sound: name, haptic: haptic)
        if activeSection == 1 {
            viewModel.config.wakeUpSound = selection
        } else {
            viewModel.config.bedtimeSound = selection
        }
        refreshSoundLabels()
    }
}

// MARK: - Slider styling
private extension AlarmOptionViewController {
    func styleSlider(_ slider: UISlider?) {
        guard let slider else { return }
        slider.minimumTrackTintColor = WakeWellTheme.accentPurple
        slider.maximumTrackTintColor = WakeWellTheme.border
        slider.setValue(max(slider.value, 0.5), animated: false)
        slider.setThumbImage(makeThumb(), for: .normal)
        slider.setThumbImage(makeThumb(), for: .highlighted)
        slider.setMinimumTrackImage(makeTrack(WakeWellTheme.accentPurple), for: .normal)
        slider.setMaximumTrackImage(makeTrack(WakeWellTheme.border), for: .normal)
    }

    func makeThumb() -> UIImage? {
        let size = CGSize(width: 22, height: 22)
        return UIGraphicsImageRenderer(size: size).image { ctx in
            WakeWellTheme.accentGold.setFill()
            ctx.cgContext.fillEllipse(in: CGRect(origin: .zero, size: size))
        }
    }

    func makeTrack(_ color: UIColor) -> UIImage? {
        let size = CGSize(width: 8, height: 8)
        let image = UIGraphicsImageRenderer(size: size).image { ctx in
            let path = UIBezierPath(roundedRect: CGRect(origin: .zero, size: size),
                                    cornerRadius: size.height / 2)
            color.setFill(); path.fill()
        }
        return image.resizableImage(withCapInsets: UIEdgeInsets(top: 0, left: 4, bottom: 0, right: 4),
                                    resizingMode: .stretch)
    }
}
