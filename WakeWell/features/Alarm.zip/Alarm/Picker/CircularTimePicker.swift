//
//  CircularTimePicker.swift
//  WakeWell
//
//  Self-contained circular sleep/wake picker.
//  Matches the reference design: header info panel above the ring,
//  clock labels inside the ring, duration label below — all WakeWell-themed.
//

import UIKit

enum SelectedHandle {
    case none, bed, sun
}

@IBDesignable
class CircularTimePicker: UIControl {

    // MARK: - Public

    var bedtime: Date { angleToDate(startAngle) }
    var wakeUp:  Date { angleToDate(endAngle) }

    var startAngle: CGFloat = CGFloat.pi          // midnight  → left side
    var endAngle:   CGFloat = 0                   // noon      → right side

    // MARK: - Layout zones (set in layoutSubviews)
    private var ringCenter:  CGPoint = .zero
    private var ringRadius:  CGFloat = 0          // centre of the arc stroke
    private var ringInset:   CGFloat = 26         // half of track lineWidth

    // MARK: - Arc layers
    private let trackLayer    = CAShapeLayer()
    private let progressLayer = CAShapeLayer()

    // MARK: - Handle layers
    private let bedHandle = CAShapeLayer()   // filled circle at start
    private let sunHandle = CAShapeLayer()   // filled circle at end

    // MARK: - Header labels (inside the view, above the ring)
    private let bedHeaderStack  = UIStackView()
    private let wakeHeaderStack = UIStackView()

    private let bedCapLabel   = UILabel()   // "Bed Time"
    private let bedTimeLabel  = UILabel()   // "12:00 AM"
    private let bedNightLabel = UILabel()   // "Tonight"

    private let wakeCapLabel  = UILabel()   // "Wake-up Time"
    private let wakeTimeLabel = UILabel()   // "12:00 PM"
    private let wakeDayLabel  = UILabel()   // "Tomorrow"

    // MARK: - Clock labels inside the ring
    private var clockLabels: [UILabel] = []

    // MARK: - Duration label (below the ring)
    private let durationLabel = UILabel()

    // MARK: - State
    private var selectedHandle: SelectedHandle = .none
    private var didBuildSubviews = false

    // MARK: - Geometry constants
    private let trackWidth:  CGFloat = 38
    private let handleSize:  CGFloat = 38   // diameter of the end-cap circles
    private let headerH: CGFloat = 70
    private let footerH: CGFloat = 30

    // MARK: - Init

    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        commonInit()
    }

    private func commonInit() {
        backgroundColor    = WakeWellTheme.cardElevated
        layer.cornerRadius = 20
        clipsToBounds      = true

        // Track (full circle, background)
        trackLayer.fillColor   = UIColor.clear.cgColor
        trackLayer.strokeColor = WakeWellTheme.border.cgColor
        trackLayer.lineWidth   = trackWidth
        layer.addSublayer(trackLayer)

        // Progress arc
        progressLayer.fillColor   = UIColor.clear.cgColor
        progressLayer.strokeColor = WakeWellTheme.accentGold.cgColor
        progressLayer.lineWidth   = trackWidth
        progressLayer.lineCap     = .round
        layer.addSublayer(progressLayer)

        // Handle layers (filled circles drawn on top of arc ends)
        [bedHandle, sunHandle].forEach {
            $0.fillColor   = WakeWellTheme.accentPurple.cgColor
            $0.strokeColor = UIColor.clear.cgColor
            layer.addSublayer($0)
        }
        sunHandle.fillColor = WakeWellTheme.accentGold.cgColor

        buildSubviews()

        addGestureRecognizer(
            UIPanGestureRecognizer(target: self, action: #selector(handlePan(_:)))
        )
    }

    // MARK: - Build subviews

    private func buildSubviews() {
        guard !didBuildSubviews else { return }
        didBuildSubviews = true

        // ── Header stacks ──
        func makeStack() -> UIStackView {
            let s = UIStackView()
            s.axis      = .vertical
            s.alignment = .center
            s.spacing   = 2
            s.translatesAutoresizingMaskIntoConstraints = false
            return s
        }

        // Caption style
        [bedCapLabel, wakeCapLabel].forEach {
            $0.font      = .systemFont(ofSize: 13, weight: .regular)
            $0.textColor = WakeWellTheme.labelSecondary
        }
        bedCapLabel.text  = "Bed Time"
        wakeCapLabel.text = "Wake-up Time"

        // Time style
        [bedTimeLabel, wakeTimeLabel].forEach {
            $0.font      = .systemFont(ofSize: 20, weight: .bold)
            $0.textColor = WakeWellTheme.labelPrimary
        }

        // Day style
        [bedNightLabel, wakeDayLabel].forEach {
            $0.font      = .systemFont(ofSize: 13, weight: .regular)
            $0.textColor = WakeWellTheme.labelSecondary
        }
        bedNightLabel.text = "Tonight"
        wakeDayLabel.text  = "Tomorrow"

        let bedStack  = makeStack()
        bedStack.addArrangedSubview(bedCapLabel)
        bedStack.addArrangedSubview(bedTimeLabel)
        bedStack.addArrangedSubview(bedNightLabel)

        let wakeStack = makeStack()
        wakeStack.addArrangedSubview(wakeCapLabel)
        wakeStack.addArrangedSubview(wakeTimeLabel)
        wakeStack.addArrangedSubview(wakeDayLabel)

        addSubview(bedStack)
        addSubview(wakeStack)

        NSLayoutConstraint.activate([
            bedStack.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 20),
            bedStack.topAnchor.constraint(equalTo: topAnchor, constant: 16),

            wakeStack.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -20),
            wakeStack.topAnchor.constraint(equalTo: topAnchor, constant: 16),
        ])

        // ── Clock labels (inside ring) ──
        let texts = ["12PM", "3PM", "6PM", "9PM", "12AM", "3AM", "6AM", "9AM"]
        clockLabels = texts.map { text in
            let l       = UILabel()
            l.text      = text
            l.font      = .systemFont(ofSize: 11, weight: .semibold)
            l.textColor = WakeWellTheme.labelSecondary
            l.sizeToFit()
            addSubview(l)
            return l
        }

        // ── Duration label (below ring) ──
        durationLabel.font          = .systemFont(ofSize: 17, weight: .bold)
        durationLabel.textColor     = WakeWellTheme.labelPrimary
        durationLabel.textAlignment = .center
        durationLabel.translatesAutoresizingMaskIntoConstraints = false
        addSubview(durationLabel)

        NSLayoutConstraint.activate([
            durationLabel.centerXAnchor.constraint(equalTo: centerXAnchor),
            durationLabel.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -14),
        ])

        refreshLabels()
    }

    // MARK: - Layout

    override func layoutSubviews() {
        super.layoutSubviews()

        // Ring occupies the space between header and footer
        let ringAreaTop    = headerH
        let ringAreaBottom = bounds.height - footerH
        let ringAreaHeight = ringAreaBottom - ringAreaTop
        let diameter = min(bounds.width - 20, ringAreaHeight)
        ringRadius  = diameter / 2 - ringInset
        ringCenter  = CGPoint(
            x: bounds.midX,
            y: ringAreaTop + ringAreaHeight / 2
        )

        // Full track circle
        let fullPath = UIBezierPath(
            arcCenter: ringCenter, radius: ringRadius,
            startAngle: 0, endAngle: .pi * 2, clockwise: true
        )
        trackLayer.path = fullPath.cgPath

        // Tick dashes (drawn once via a separate layer if not already added)
        if layer.sublayers?.first(where: { $0.name == "ticks" }) == nil {
            let ticks             = CAShapeLayer()
            ticks.name            = "ticks"
            ticks.path            = UIBezierPath(
                arcCenter: ringCenter, radius: ringRadius,
                startAngle: 0, endAngle: .pi * 2, clockwise: true
            ).cgPath
            ticks.fillColor       = UIColor.clear.cgColor
            ticks.strokeColor     = WakeWellTheme.cardBackground.cgColor
            ticks.lineWidth       = trackWidth - 4
            ticks.lineDashPattern = [2, 7]
            layer.insertSublayer(ticks, above: trackLayer)
        }

        updateArc()
        repositionClockLabels()
    }

    // MARK: - Arc & handles

    private func updateArc() {
        // Progress arc
        let arcPath = UIBezierPath(
            arcCenter: ringCenter, radius: ringRadius,
            startAngle: startAngle, endAngle: endAngle, clockwise: true
        )
        progressLayer.path = arcPath.cgPath

        // Handle circles — drawn as filled CAShapeLayer circles centered on arc endpoints
        placeHandle(bedHandle, at: startAngle, color: WakeWellTheme.accentPurple)
        placeHandle(sunHandle, at: endAngle,   color: WakeWellTheme.accentGold)
    }

    private func placeHandle(_ handle: CAShapeLayer, at angle: CGFloat, color: UIColor) {
        let pt = pointOnRing(angle: angle)
        let r  = handleSize / 2
        let rect = CGRect(x: pt.x - r, y: pt.y - r, width: handleSize, height: handleSize)
        handle.path      = UIBezierPath(ovalIn: rect).cgPath
        handle.fillColor = color.cgColor
    }

    // MARK: - Clock labels inside the ring

    private func repositionClockLabels() {
        // Labels sit on a circle inside the track inner edge
        let labelR = ringRadius - ringInset - 18
        for (i, label) in clockLabels.enumerated() {
            let angle = (-.pi / 2) + CGFloat(i) * (.pi / 4)
            label.sizeToFit()
            label.center = CGPoint(
                x: ringCenter.x + labelR * cos(angle),
                y: ringCenter.y + labelR * sin(angle)
            )
        }
    }

    // MARK: - Header & duration labels

    func refreshLabels() {
        bedTimeLabel.text  = formatTime(bedtime)
        wakeTimeLabel.text = formatTime(wakeUp)
        durationLabel.text = durationString()
    }

    private func durationString() -> String {
        var diff = Calendar.current.dateComponents(
            [.hour, .minute], from: bedtime, to: wakeUp
        )
        var h = diff.hour ?? 0
        var m = diff.minute ?? 0
        if h < 0 || (h == 0 && m < 0) { h += 24 }
        if m < 0 { m += 60; h -= 1 }
        return m == 0 ? "\(h) hr" : "\(h) hr \(m) min"
    }

    // MARK: - Gesture

    @objc private func handlePan(_ gesture: UIPanGestureRecognizer) {
        let loc   = gesture.location(in: self)
        let angle = atan2(loc.y - ringCenter.y, loc.x - ringCenter.x)

        if gesture.state == .began {
            let bedPt = pointOnRing(angle: startAngle)
            let sunPt = pointOnRing(angle: endAngle)
            let bd    = hypot(loc.x - bedPt.x, loc.y - bedPt.y)
            let sd    = hypot(loc.x - sunPt.x, loc.y - sunPt.y)
            if bd < sd && bd < 44      { selectedHandle = .bed }
            else if sd < bd && sd < 44 { selectedHandle = .sun }
            else                       { selectedHandle = .none }
        }

        if gesture.state == .changed {
            if selectedHandle == .bed      { startAngle = angle }
            else if selectedHandle == .sun { endAngle   = angle }
            updateArc()
            refreshLabels()
            sendActions(for: .valueChanged)
        }
    }

    // MARK: - Theme hook (called from AlarmPickerCell.awakeFromNib)

    func applyTheme() {
        backgroundColor    = WakeWellTheme.cardElevated
        layer.cornerRadius = 20
        // No clipsToBounds needed — all labels are correctly inside bounds
        trackLayer.strokeColor    = WakeWellTheme.border.cgColor
        progressLayer.strokeColor = WakeWellTheme.accentGold.cgColor
        updateArc()
        refreshLabels()
    }

    // MARK: - Math

    private func pointOnRing(angle: CGFloat) -> CGPoint {
        CGPoint(
            x: ringCenter.x + ringRadius * cos(angle),
            y: ringCenter.y + ringRadius * sin(angle)
        )
    }

    private func angleToDate(_ angle: CGFloat) -> Date {
        // angle 0 = 3 o'clock = 6 AM in a 24h clock starting midnight at top
        // top = -π/2, so offset = angle + π/2
        var n = angle + .pi / 2
        if n < 0       { n += 2 * .pi }
        if n > 2 * .pi { n -= 2 * .pi }
        let minutes = (n / (2 * .pi)) * (24 * 60)
        var c        = Calendar.current.dateComponents([.year, .month, .day], from: Date())
        c.hour   = 0
        c.minute = Int(minutes)
        return Calendar.current.date(from: c) ?? Date()
    }

    func formatTime(_ date: Date) -> String {
        let f        = DateFormatter()
        f.dateFormat = "h:mm a"
        return f.string(from: date)
    }
}
