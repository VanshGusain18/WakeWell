//
//  CircularTimePicker.swift
//  WakeWell
//
//  @IBDesignable circular time picker used in the alarm screen.
//  Drop into a XIB / Storyboard as a custom view; set class to CircularTimePicker.
//

import UIKit

enum SelectedHandle {
    case none, bed, sun
}

@IBDesignable
class CircularTimePicker: UIControl {

    // MARK: - Public accessors
    var bedtime: Date { angleToDate(startAngle) }
    var wakeUp:  Date { angleToDate(endAngle)   }

    var startAngle: CGFloat = 3 * .pi / 2   // ≈ 10:30 PM
    var endAngle:   CGFloat =     .pi / 2   // ≈  7:30 AM

    // MARK: - Private layers
    private let trackLayer      = CAShapeLayer()
    private let progressLayer   = CAShapeLayer()
    private let outerCircleLayer = CAShapeLayer()
    private let bedHandle       = CALayer()
    private let sunHandle       = CALayer()
    private var selectedHandle: SelectedHandle = .none
    private var isConfigured    = false

    // MARK: - Init

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupView()
    }

    private func setupView() {
        outerCircleLayer.strokeColor = WakeWellTheme.border.cgColor
        outerCircleLayer.fillColor   = UIColor.clear.cgColor
        outerCircleLayer.lineWidth   = 10
        layer.addSublayer(outerCircleLayer)

        trackLayer.strokeColor = WakeWellTheme.cardBackground.cgColor
        trackLayer.fillColor   = UIColor.clear.cgColor
        trackLayer.lineWidth   = 40
        layer.addSublayer(trackLayer)

        progressLayer.strokeColor = WakeWellTheme.accentGold.cgColor
        progressLayer.fillColor   = UIColor.clear.cgColor
        progressLayer.lineWidth   = 40
        progressLayer.lineCap     = .round
        layer.addSublayer(progressLayer)

        addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(handlePan(_:))))
    }

    // MARK: - Layout

    override func layoutSubviews() {
        super.layoutSubviews()

        let center = CGPoint(x: bounds.midX, y: bounds.midY)
        let radius = (min(bounds.width, bounds.height) / 2) - 30

        let full = UIBezierPath(arcCenter: center, radius: radius,
                                startAngle: 0, endAngle: .pi * 2, clockwise: true)
        trackLayer.path = full.cgPath

        let outer = UIBezierPath(arcCenter: center, radius: radius + 20,
                                 startAngle: 0, endAngle: .pi * 2, clockwise: true)
        outerCircleLayer.path = outer.cgPath

        if !isConfigured {
            isConfigured = true
            addClockLabels()
            drawTicks()
        }

        updateUI()
    }

    // MARK: - Drawing

    private func updateUI() {
        let center = CGPoint(x: bounds.midX, y: bounds.midY)
        let radius = (min(bounds.width, bounds.height) / 2) - 30

        // Progress arc
        var sweep = endAngle - startAngle
        if sweep < 0 { sweep += 2 * .pi }
        let prog = UIBezierPath(arcCenter: center, radius: radius,
                                startAngle: startAngle, endAngle: endAngle, clockwise: true)
        progressLayer.path = prog.cgPath

        // Bed handle (moon icon)
        let bedPos = position(for: startAngle, in: bounds, margin: 10)
        bedHandle.removeFromSuperlayer()
        let bedSize: CGFloat = 44
        bedHandle.frame = CGRect(x: bedPos.x - bedSize / 2,
                                 y: bedPos.y - bedSize / 2,
                                 width: bedSize, height: bedSize)
        bedHandle.cornerRadius  = bedSize / 2
        bedHandle.backgroundColor = WakeWellTheme.accentPurple.cgColor
        drawIcon(symbol: "moon.fill", in: bedHandle)
        layer.addSublayer(bedHandle)

        // Sun handle (sun icon)
        let sunPos = position(for: endAngle, in: bounds, margin: 10)
        sunHandle.removeFromSuperlayer()
        let sunSize: CGFloat = 44
        sunHandle.frame = CGRect(x: sunPos.x - sunSize / 2,
                                 y: sunPos.y - sunSize / 2,
                                 width: sunSize, height: sunSize)
        sunHandle.cornerRadius  = sunSize / 2
        sunHandle.backgroundColor = WakeWellTheme.accentGold.cgColor
        drawIcon(symbol: "sun.max.fill", in: sunHandle)
        layer.addSublayer(sunHandle)
    }

    private func drawIcon(symbol: String, in layer: CALayer) {
        guard let config = UIImage.SymbolConfiguration(
                pointSize: 18, weight: .medium) as? UIImage.SymbolConfiguration,
              let image = UIImage(systemName: symbol, withConfiguration: config)?
                .withTintColor(.white, renderingMode: .alwaysOriginal)
        else { return }

        let iconLayer          = CALayer()
        iconLayer.contents     = image.cgImage
        let size: CGFloat      = 20
        iconLayer.frame        = CGRect(
            x: (layer.bounds.width  - size) / 2,
            y: (layer.bounds.height - size) / 2,
            width: size, height: size
        )
        iconLayer.contentsGravity = .resizeAspect
        layer.addSublayer(iconLayer)
    }

    // MARK: - Clock labels & ticks

    private func addClockLabels() {
        let labels = ["12PM", "3PM", "6PM", "9PM", "12AM", "3AM", "6AM", "9AM"]
        for (i, text) in labels.enumerated() {
            let angle = (-.pi / 2) + CGFloat(i) * (.pi / 4)
            let label = UILabel()
            label.text      = text
            label.font      = .systemFont(ofSize: 11, weight: .semibold)
            label.textColor = WakeWellTheme.labelSecondary
            label.sizeToFit()
            label.center    = position(for: angle, in: bounds, margin: 75)
            addSubview(label)
        }
    }

    private func drawTicks() {
        let tickLayer = CAShapeLayer()
        let center    = CGPoint(x: bounds.midX, y: bounds.midY)
        let radius    = (min(bounds.width, bounds.height) / 2) - 45
        let path      = UIBezierPath(arcCenter: center, radius: radius,
                                     startAngle: 0, endAngle: .pi * 2, clockwise: true)
        tickLayer.path          = path.cgPath
        tickLayer.fillColor     = UIColor.clear.cgColor
        tickLayer.strokeColor   = WakeWellTheme.border.cgColor
        tickLayer.lineWidth     = 8
        tickLayer.lineDashPattern = [2, 6]
        layer.insertSublayer(tickLayer, below: progressLayer)
    }

    // MARK: - Gesture

    @objc private func handlePan(_ gesture: UIPanGestureRecognizer) {
        let loc    = gesture.location(in: self)
        let center = CGPoint(x: bounds.midX, y: bounds.midY)
        let angle  = atan2(loc.y - center.y, loc.x - center.x)

        if gesture.state == .began {
            let bedPos = position(for: startAngle, in: bounds, margin: 10)
            let sunPos = position(for: endAngle,   in: bounds, margin: 10)
            let bedDist = hypot(loc.x - bedPos.x, loc.y - bedPos.y)
            let sunDist = hypot(loc.x - sunPos.x, loc.y - sunPos.y)

            if bedDist < sunDist && bedDist < 40 {
                selectedHandle = .bed
            } else if sunDist < bedDist && sunDist < 40 {
                selectedHandle = .sun
            } else {
                selectedHandle = .none
            }
        }

        if gesture.state == .changed {
            if selectedHandle == .bed { startAngle = angle }
            else if selectedHandle == .sun { endAngle = angle }
            updateUI()
            sendActions(for: .valueChanged)
        }
    }

    // MARK: - Theme

    func applyTheme() {
        backgroundColor = WakeWellTheme.cardElevated
        outerCircleLayer.strokeColor = WakeWellTheme.border.cgColor
        trackLayer.strokeColor       = WakeWellTheme.cardBackground.cgColor
        progressLayer.strokeColor    = WakeWellTheme.accentGold.cgColor
        layer.cornerRadius = 20
        clipsToBounds = true
        updateUI()
    }

    // MARK: - Math helpers

    private func angleToDate(_ angle: CGFloat) -> Date {
        var n = angle + .pi / 2
        if n < 0 { n += 2 * .pi }
        if n > 2 * .pi { n -= 2 * .pi }
        let minutes = (n / (2 * .pi)) * (24 * 60)
        var c = Calendar.current.dateComponents([.year, .month, .day], from: Date())
        c.hour   = 0
        c.minute = Int(minutes)
        return Calendar.current.date(from: c) ?? Date()
    }

    func formatTime(_ date: Date) -> String {
        let f = DateFormatter()
        f.dateFormat = "h:mm a"
        return f.string(from: date)
    }

    private func position(for angle: CGFloat, in rect: CGRect, margin: CGFloat) -> CGPoint {
        let center = CGPoint(x: rect.midX, y: rect.midY)
        let radius = (min(rect.width, rect.height) / 2) - margin
        return CGPoint(x: center.x + radius * cos(angle),
                       y: center.y + radius * sin(angle))
    }
}
