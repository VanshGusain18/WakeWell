//
//  AlarmSliderCell.swift
//  WakeWell

import UIKit

final class AlarmSliderCell: UITableViewCell {

    static let reuseID = "AlarmSliderCell"

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var slider:     UISlider!

    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle  = .none
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        titleLabel.textColor = WakeWellTheme.labelPrimary
        styleSlider()
    }

    private func styleSlider() {
        slider.minimumTrackTintColor = WakeWellTheme.accentPurple
        slider.maximumTrackTintColor = WakeWellTheme.border

        let thumbSize = CGSize(width: 22, height: 22)
        let thumb = UIGraphicsImageRenderer(size: thumbSize).image { ctx in
            WakeWellTheme.accentGold.setFill()
            ctx.cgContext.fillEllipse(in: CGRect(origin: .zero, size: thumbSize))
        }
        slider.setThumbImage(thumb, for: .normal)
        slider.setThumbImage(thumb, for: .highlighted)

        slider.setMinimumTrackImage(makeTrack(WakeWellTheme.accentPurple), for: .normal)
        slider.setMaximumTrackImage(makeTrack(WakeWellTheme.border),        for: .normal)
    }

    private func makeTrack(_ color: UIColor) -> UIImage {
        let size = CGSize(width: 8, height: 8)
        let img = UIGraphicsImageRenderer(size: size).image { ctx in
            let path = UIBezierPath(roundedRect: CGRect(origin: .zero, size: size), cornerRadius: 4)
            color.setFill(); path.fill()
        }
        return img.resizableImage(
            withCapInsets: UIEdgeInsets(top: 0, left: 4, bottom: 0, right: 4),
            resizingMode: .stretch
        )
    }
}
